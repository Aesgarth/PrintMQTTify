#!/bin/sh

echo "Shell Script CUPS Driver Installing Started !!!"
cd install;chmod +x setup
exec ./setup
echo "Shell Script CUPS Driver Installing Ended !!!"

